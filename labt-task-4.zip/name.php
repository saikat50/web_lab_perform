<?php

$count = 0;
$nameErr = '';


if($_SERVER['REQUEST_METHOD']=='POST'){
    
    $name = $_POST['name'];
    $count = strlen($_POST['name']);
    
    if($count < 2){
        $nameErr = "name at least 2 char";
    }
    if(preg_match("/^[a-zA-Z]/", $name[0])){
        
    }
    else{
        $nameErr = "must start with character";
    }
    
}




?>

    
<fieldset>

	<legend>Name</legend>
<form action="" method="POST">
	<input type="text" name="name" value="" required><br>
	<?php echo $nameErr . "<br>"; ?>
	<input type="submit">
</form>

</fieldset>