
<?php

$count = 0;
$ddErr = '';
$mmErr = '';
$yyErr = '';


if($_SERVER['REQUEST_METHOD']=='POST'){
    
    $dd = $_POST['dd'];
    $mm = $_POST['mm'];
    $yy = $_POST['yy'];
    
    
    if($dd < 1|| $dd > 31){
         $ddErr = "must between 1 to 31";
    }
    
    if(preg_match("/^[1-12]/", $mm)){
         $mmErr = "must between 1 to 12";
    }
    if($yy < 1953 || $yy > 1998){
         $yyErr = "must between 1953 to 1998";
    }
    
    
}




?>

   
   
    
<fieldset>

	<legend>Email</legend>
<form action="" method="POST">
	<input type="text" name="dd" value="" required placeholder="dd"><br>
	<?php echo $ddErr . "<br>"; ?>
	<input type="text" name="mm" value="" required placeholder="mm"><br>
    <?php echo $mmErr . "<br>"; ?>
	<input type="text" name="yy" value="" required placeholder="yyyy">
    <?php echo $yyErr . "<br>"; ?>
	<input type="submit">
</form>

</fieldset>