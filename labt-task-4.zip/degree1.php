<?php

$checkErr = '';
$count = 0;

if($_SERVER['REQUEST_METHOD']=='POST'){
    
    
    if(isset($_POST['SSC']) && ($_POST['SSC']=="SSC")){
        $count++;
    }
    
    if(isset($_POST['HSC']) && ($_POST['HSC']=="HSC")){
         $count++;
    }
    
    if(isset($_POST['BSc']) && ($_POST['BSc']=="BSc")){
        $count++;
    }
    
    if(isset($_POST['MSc']) && ($_POST['MSc']=="MSc")){
        $count;
    }
    
    if($count < 2){
        $checkErr = "check at least 2";
    }
    
  
}



?>



<fieldset>


<form action="degree1.php" method="post">
	<legend>Email</legend>
	<input type="checkbox" name="SSC" value="SSC">SSC
	<input type="checkbox" name="HSC" value="HSC">HSC
	<input type="checkbox" name="BSc" value="BSc">BSc
	<input type="checkbox" name="MSc" value="MSc">MSc<br>
	<?php echo $checkErr . "<br>" ?>
	<input type="submit">
	
</form>

</fieldset>