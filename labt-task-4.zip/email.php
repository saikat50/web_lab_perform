
    
<fieldset>

	<legend>Email</legend>
<form action="" method="POST">
	<input type="email" name="name" value="" required><br>
	<input type="submit">
</form>

</fieldset>