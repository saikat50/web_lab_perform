<?php

$checkErr = '';


if($_SERVER['REQUEST_METHOD']=='POST'){
    
    if($_POST['blood']==''){
        $checkErr = 'must selected';
    }
    
  
}



?>




<fieldset>
<form action="blood1.php" method="post">
	<legend>Blood Group</legend>
	<select name="blood">
	    <option value=""></option>
		<option value="1">1</option>
		<option value="2">2</option>
		<option value="3">3</option>
	</select>
	
    <?php echo "<br>" . $checkErr . "<br>" ?>
	
	<input type="submit">
	
</form>

</fieldset>